import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt



# 1) Parameters

@dataclass
class ParamsFB:
    # sensing core
    alpha_AbaR: float = 5.0        # nM/min (constitutive)
    gamma_AbaR: float = 0.02       # 1/min

    k_in: float = 1.0              # 1/min
    k_out: float = 1.0             # 1/min

    k_on: float = 1e6 / 1e9 * 60   # nM^-1 min^-1  (from 1e6 M^-1 s^-1)
    k_off: float = 1e-2 * 60       # 1/min         (from 1e-2 s^-1)
    gamma_c: float = 0.02          # 1/min

    # pAbaI* -> T7
    alpha_T7: float = 50.0         # nM/min
    beta_T7: float = 0.1           # nM/min
    gamma_T7: float = 0.02         # 1/min
    Kd_pAbaI: float = 50.0         # nM
    n_hill: float = 2.0

    # pT7 -> PvdQ
    alpha_PvdQ: float = 100.0      # nM/min
    beta_PvdQ: float = 0.1         # nM/min
    gamma_PvdQ: float = 0.01       # 1/min
    Kd_pT7: float = 20.0           # nM
    m_hill: float = 2.0

    # Positive feedback: pT7 -> extra AbaR
    alpha_AbaR_fb: float = 10.0    # nM/min (RBS strength proxy)
    Kd_pT7_AbaR: float = 20.0      # nM (T7 half-activation for AbaR feedback)
    m_fb: float = 2.0              # Hill coefficient for feedback branch


def hill(x, K, n):
    x = max(float(x), 0.0)
    return (x**n) / (K**n + x**n + 1e-12)


# 2) ODE: add a positive-feedback term to the AbaR equation
# y = [AbaR, AHL_int, Cplx, T7, PvdQ]

def ode_rhs_fb(t, y, p: ParamsFB, AHL_ext_func):
    AbaR, AHL_int, Cplx, T7, PvdQ = y
    AHL_ext = float(AHL_ext_func(t))

    fb = p.alpha_AbaR_fb * hill(T7, p.Kd_pT7_AbaR, p.m_fb)

    dAbaR = (p.alpha_AbaR + fb
             - p.gamma_AbaR * AbaR
             - p.k_on * AbaR * AHL_int
             + p.k_off * Cplx)

    dAHLint = (p.k_in * AHL_ext
               - p.k_out * AHL_int
               - p.k_on * AbaR * AHL_int
               + p.k_off * Cplx)

    dCplx = (p.k_on * AbaR * AHL_int
             - p.k_off * Cplx
             - p.gamma_c * Cplx)

    dT7 = (p.alpha_T7 * hill(Cplx, p.Kd_pAbaI, p.n_hill)
           + p.beta_T7
           - p.gamma_T7 * T7)

    dPvdQ = (p.alpha_PvdQ * hill(T7, p.Kd_pT7, p.m_hill)
             + p.beta_PvdQ
             - p.gamma_PvdQ * PvdQ)

    return [dAbaR, dAHLint, dCplx, dT7, dPvdQ]


def simulate_to_ss(p: ParamsFB, AHL_value, y0=None, t_end=1200, n_points=1201):
    if y0 is None:
        y0 = np.zeros(5)

    AHL_const = lambda t, A=AHL_value: A
    t_eval = np.linspace(0, t_end, n_points)

    sol = solve_ivp(
        fun=lambda t, y: ode_rhs_fb(t, y, p, AHL_const),
        t_span=(0, t_end),
        y0=y0,
        t_eval=t_eval,
        method="LSODA",
        rtol=1e-6,
        atol=1e-9
    )
    if not sol.success:
        raise RuntimeError(sol.message)

    y = sol.y
    tail = slice(int(0.9 * y.shape[1]), y.shape[1])
    ss = np.mean(y[:, tail], axis=1)
    return ss



# 3) Hysteresis curve: AHL up-sweep / down-sweep (warm-start)

def hysteresis_curve(p: ParamsFB, AHL_grid, t_end=1200):
    AHL_grid = np.array(AHL_grid, dtype=float)

    # up-sweep
    ss_up = []
    y0 = np.zeros(5)
    for A in AHL_grid:
        y0 = simulate_to_ss(p, A, y0=y0, t_end=t_end)
        ss_up.append(y0)
    ss_up = np.array(ss_up)

    # down-sweep
    ss_down = []
    y0 = ss_up[-1].copy()  # start from an ON-ish state
    for A in AHL_grid[::-1]:
        y0 = simulate_to_ss(p, A, y0=y0, t_end=t_end)
        ss_down.append(y0)
    ss_down = np.array(ss_down)[::-1]  # align order with AHL_grid

    return ss_up, ss_down


def estimate_on_off(AHL_grid, out_up, out_down):
    AHL_grid = np.array(AHL_grid, dtype=float)
    out_up = np.array(out_up, dtype=float)
    out_down = np.array(out_down, dtype=float)

    off_level = float(out_up[0])
    on_level = float(out_down[-1])  # typically ON at high AHL
    thr = 0.5 * (off_level + on_level)

    # AHL_on: first crossing above threshold during up-sweep
    idx_on = np.where(out_up >= thr)[0]
    A_on = np.nan if len(idx_on) == 0 else AHL_grid[idx_on[0]]

    # AHL_off: first drop below threshold during down-sweep
    # (stays ON while sweeping down; turns OFF only after dropping below threshold)
    idx_drop = np.where(out_down < thr)[0]
    if len(idx_drop) == 0:
        A_off = np.nan
    else:
        k = idx_drop[0]
        A_off = AHL_grid[k-1] if k > 0 else AHL_grid[0]

    Delta = np.nan if (np.isnan(A_on) or np.isnan(A_off)) else max(0.0, A_on - A_off)
    return A_on, A_off, Delta, thr



# 4) Nullclines
# Reduced assumptions:
# - AHL_int is fast: AHL_int ≈ (k_in/k_out) * AHL_ext
# - Binding is fast: C ≈ R_total * AHL_int/(Kd_bind + AHL_int), Kd_bind = k_off/k_on
# - R_total steady state from dR/dt=0: R_ss(T7) = (alpha_const + alpha_fb*hill(T7))/gamma
# Then obtain C-nullcline: C(T7); and T7-nullcline: T7(C)
def plot_nullclines_reduced(p: ParamsFB, AHL_ext, T7_max=4000, n=600):
    Kd_bind = p.k_off / p.k_on
    AHL_int = (p.k_in / p.k_out) * AHL_ext

    T7 = np.linspace(0, T7_max, n)

    # C-nullcline: C as a function of T7 (via R_ss)
    R_ss = (p.alpha_AbaR + p.alpha_AbaR_fb * (T7**p.m_fb)/(p.Kd_pT7_AbaR**p.m_fb + T7**p.m_fb + 1e-12)) / p.gamma_AbaR
    C_of_T7 = R_ss * AHL_int / (Kd_bind + AHL_int + 1e-12)

    # T7-nullcline: explicit T7(C)
    C = np.linspace(0, max(1.0, np.max(C_of_T7)*1.1), n)
    T7_of_C = (p.alpha_T7 * (C**p.n_hill)/(p.Kd_pAbaI**p.n_hill + C**p.n_hill + 1e-12) + p.beta_T7) / p.gamma_T7

    plt.figure(figsize=(6.5, 5))
    plt.plot(C_of_T7, T7, label="C-nullcline (dR/dt=0 approx)", lw=2)
    plt.plot(C, T7_of_C, label="T7-nullcline (dT7/dt=0)", lw=2)
    plt.xlabel("C = [AbaR:AHL] (nM)  (approx)")
    plt.ylabel("T7 (nM)")
    plt.title(f"Reduced nullclines at [AHL_ext]={AHL_ext} nM")
    plt.legend()
    plt.tight_layout()
    plt.show()

# 5) Scan alpha_AbaR_fb (RBS strength proxy) -> Δ
# + Simple burden metric: approximate by the total production flux in the ON state

def burden_proxy(p: ParamsFB, ss):
    AbaR, AHL_int, Cplx, T7, PvdQ = ss
    fb = p.alpha_AbaR_fb * hill(T7, p.Kd_pT7_AbaR, p.m_fb)
    prod = (p.alpha_AbaR + fb) \
           + (p.alpha_T7 * hill(Cplx, p.Kd_pAbaI, p.n_hill) + p.beta_T7) \
           + (p.alpha_PvdQ * hill(T7, p.Kd_pT7, p.m_hill) + p.beta_PvdQ)
    return float(prod)


if __name__ == "__main__":
    p = ParamsFB(alpha_AbaR_fb=20.0)

    # A) Plot a hysteresis “effect figure” (use up/down sweeps as a continuation approximation)
    AHL_grid = np.logspace(-2, 2.7, 45)  # 0.01 ~ 500 nM
    ss_up, ss_down = hysteresis_curve(p, AHL_grid, t_end=1200)

    PvdQ_up = ss_up[:, 4]
    PvdQ_down = ss_down[:, 4]

    A_on, A_off, Delta, thr = estimate_on_off(AHL_grid, PvdQ_up, PvdQ_down)
    print(f"[AHL]_on ≈ {A_on:.3g} nM, [AHL]_off ≈ {A_off:.3g} nM, Δ ≈ {Delta:.3g} nM (threshold={thr:.3g})")

    plt.figure(figsize=(7, 4.8))
    plt.semilogx(AHL_grid, PvdQ_up, "-o", ms=3, label="Up-sweep (OFF→ON)")
    plt.semilogx(AHL_grid, PvdQ_down, "-o", ms=3, label="Down-sweep (ON→OFF)")
    plt.axhline(thr, color="k", ls="--", lw=1, label="Mid threshold")
    if not np.isnan(A_on):  plt.axvline(A_on, color="C0", ls=":", lw=1)
    if not np.isnan(A_off): plt.axvline(A_off, color="C1", ls=":", lw=1)
    plt.xlabel("[AHL_ext] (nM)")
    plt.ylabel("PvdQ steady state (nM)")
    plt.title("Hysteresis (bistability) via up/down sweeps")
    plt.legend()
    plt.tight_layout()
    plt.show()

    # B) Plot nullclines (reduced phase-plane illustration)
    plot_nullclines_reduced(p, AHL_ext=10.0, T7_max=3500)

    # C) Scan alpha_AbaR_fb -> Δ, with an example burden constraint
    alpha_fb_list = np.logspace(-1, 2.0, 25)  # 0.1 ~ 100 nM/min
    Deltas = []
    burdens = []
    feasible = []
    burden_tol = 250.0  # user-defined; adjust for the real system

    for a in alpha_fb_list:
        p2 = ParamsFB(**{**p.__dict__, "alpha_AbaR_fb": float(a)})
        ss_up2, ss_down2 = hysteresis_curve(p2, AHL_grid, t_end=1000)
        P_up2 = ss_up2[:, 4]
        P_dn2 = ss_down2[:, 4]
        A_on2, A_off2, Delta2, _ = estimate_on_off(AHL_grid, P_up2, P_dn2)
        Deltas.append(Delta2)

        # Use the last point of the down branch at high AHL as the “ON state”
        ss_on = ss_down2[-1]
        b = burden_proxy(p2, ss_on)
        burdens.append(b)
        feasible.append(b < burden_tol)

    Deltas = np.array(Deltas, dtype=float)
    burdens = np.array(burdens, dtype=float)
    feasible = np.array(feasible, dtype=bool)

    plt.figure(figsize=(7, 4.8))
    plt.semilogx(alpha_fb_list, Deltas, "-o", ms=3, label="Δ (hysteresis width)")
    plt.semilogx(alpha_fb_list[~feasible], Deltas[~feasible], "ro", ms=4, label="burden too high")
    plt.xlabel("alpha_AbaR_fb (nM/min)  ~ RBS strength")
    plt.ylabel("Δ = [AHL]_on - [AHL]_off (nM)")
    plt.title("RBS(α_fb) scan for maximizing hysteresis window")
    plt.legend()
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(7, 4.8))
    plt.semilogx(alpha_fb_list, burdens, "-o", ms=3)
    plt.axhline(burden_tol, color="r", ls="--", lw=1)
    plt.xlabel("alpha_AbaR_fb (nM/min)")
    plt.ylabel("Burden proxy (a.u., production flux)")
    plt.title("Burden proxy vs feedback strength")
    plt.tight_layout()
    plt.show()