import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

@dataclass
class Params:
    # effective population scaling (unitless multiplier)
    N0: float = 1.0

    # Arabinose metabolism per live population (Ara units/min)
    Vmax_Ara: float = 0.0016     # tuned so Ara0~2 depletes around ~24h if S~1
    Km_Ara: float = 0.25
    delta_Ara: float = 2e-4      # 1/min abiotic loss (small)

    # MazE induced by Ara (Hill)
    alpha_MazE: float = 0.45     # a.u./min (RBS strength proxy)
    K_Ara: float = 0.35
    n_A: float = 2.0
    gamma_MazE: float = np.log(2)/30.0   # 1/min (t1/2 ~ 30 min)

    # MazF production: basal + Dox inducible (Hill)
    alpha_MazF_const: float = 0.010      # a.u./min (low basal)
    alpha_MazF_Dox: float = 0.060        # a.u./min (emergency boost)
    K_Dox: float = 0.6
    n_D: float = 2.0
    gamma_MazF: float = np.log(2)/240.0  # 1/min (t1/2 ~ 4 h)

    # Killing dynamics
    MazF_threshold: float = 0.8          # a.u.
    k_kill: float = 0.006               # 1/(min*a.u.) -> gradual killing (tens of min to hours)

    eps: float = 1e-12


def hill(x, K, n):
    x = max(float(x), 0.0)
    return (x**n) / (K**n + x**n + 1e-12)


def dox_of_t(t, t_emergency=np.inf, dox_level=0.0):
    return float(dox_level) if t >= t_emergency else 0.0


def rhs(t, y, p: Params, t_emergency=np.inf, dox_level=0.0):
    # States: [Ara, MazE, MazF, S]
    Ara, E, F, S = y

    Ara = max(Ara, 0.0)
    E = max(E, 0.0)
    F = max(F, 0.0)
    S = min(max(S, 0.0), 1.0)

    # live biomass factor
    N_eff = p.N0 * S

    # Ara consumption (MM) + abiotic loss
    dAra = -(p.Vmax_Ara * Ara / (p.Km_Ara + Ara + p.eps)) * N_eff - p.delta_Ara * Ara

    # expression
    prod_E = p.alpha_MazE * hill(Ara, p.K_Ara, p.n_A)

    Dox = dox_of_t(t, t_emergency=t_emergency, dox_level=dox_level)
    prod_F = p.alpha_MazF_const + p.alpha_MazF_Dox * hill(Dox, p.K_Dox, p.n_D)

    dE = prod_E - p.gamma_MazE * E
    dF = prod_F - p.gamma_MazF * F

    # fast sequestration approximation (1:1)
    F_free = max(F - E, 0.0)
    overdose = max(F_free - p.MazF_threshold, 0.0)

    # survival
    dS = -p.k_kill * overdose * S

    return [dAra, dE, dF, dS]


def simulate(p: Params, Ara0=2.0, t_end=24*60, t_emergency=np.inf, dox_level=0.0):
    y0 = [Ara0, 0.0, 0.0, 1.0]
    t_eval = np.unique(np.r_[np.linspace(0, min(240, t_end), 1201),
                             np.linspace(min(240, t_end), t_end, 1201)])
    sol = solve_ivp(
        fun=lambda t, y: rhs(t, y, p, t_emergency=t_emergency, dox_level=dox_level),
        t_span=(0, t_end),
        y0=y0,
        t_eval=t_eval,
        method="LSODA",
        rtol=1e-7,
        atol=1e-10
    )
    if not sol.success:
        raise RuntimeError(sol.message)

    Ara, E, F, S = sol.y
    F_free = np.maximum(F - E, 0.0)
    return sol.t, Ara, E, F, F_free, S


# ---------- metrics ----------
def first_time_below(t, y, thr):
    idx = np.where(y <= thr)[0]
    return np.nan if len(idx) == 0 else float(t[idx[0]])

def first_time_above(t, y, thr):
    idx = np.where(y >= thr)[0]
    return np.nan if len(idx) == 0 else float(t[idx[0]])

def kill_half_life(t, S, t_start):
    if not np.isfinite(t_start):
        return np.nan
    S0 = np.interp(t_start, t, S)
    target = 0.5 * S0
    mask = t >= t_start
    t_half_abs = first_time_below(t[mask], S[mask], target)
    return np.nan if np.isnan(t_half_abs) else (t_half_abs - t_start)

def compute_metrics(t, F_free, S, p: Params):
    T_survival = first_time_below(t, S, 0.9)
    if np.isnan(T_survival):
        T_survival = t[-1]

    t_kill_on = first_time_above(t, F_free, p.MazF_threshold)
    t_half = kill_half_life(t, S, t_kill_on)

    return T_survival, t_kill_on, t_half


def plot_scenario(t, Ara, E, F_free, S, title):
    fig, ax = plt.subplots(2, 2, figsize=(11, 7))
    ax = ax.ravel()

    ax[0].plot(t, Ara, lw=2)
    ax[0].set_title("[Ara](t)")
    ax[0].set_xlabel("t (min)"); ax[0].set_ylabel("Ara")
    ax[0].grid(True, alpha=0.25)

    ax[1].plot(t, E, lw=2, label="MazE")
    ax[1].set_title("MazE(t)")
    ax[1].set_xlabel("t (min)"); ax[1].set_ylabel("a.u.")
    ax[1].grid(True, alpha=0.25)

    ax[2].plot(t, F_free, lw=2, color="C3", label="MazF_free")
    ax[2].set_title("MazF_free(t) = max(F - E, 0)")
    ax[2].set_xlabel("t (min)"); ax[2].set_ylabel("a.u.")
    ax[2].grid(True, alpha=0.25)

    ax[3].plot(t, S, lw=2, color="k")
    ax[3].set_title("Survival S(t)")
    ax[3].set_xlabel("t (min)"); ax[3].set_ylabel("S")
    ax[3].set_ylim(-0.02, 1.02)
    ax[3].grid(True, alpha=0.25)

    fig.suptitle(title, y=1.02, fontsize=14)
    plt.tight_layout()
    plt.show()


# ---------- operating-space scan ----------
def scan_operating_space(p: Params,
                         Ara0_grid=np.linspace(0.5, 5.0, 40),
                         alphaE_grid=np.linspace(0.1, 1.2, 40),
                         t_end=24*60):
    Tsurv = np.zeros((len(alphaE_grid), len(Ara0_grid)))
    T99 = np.full_like(Tsurv, np.nan, dtype=float)

    for i, aE in enumerate(alphaE_grid):
        for j, Ara0 in enumerate(Ara0_grid):
            p2 = Params(**p.__dict__)
            p2.alpha_MazE = float(aE)

            t, Ara, E, F, F_free, S = simulate(p2, Ara0=Ara0, t_end=t_end)

            ts = first_time_below(t, S, 0.9)
            Tsurv[i, j] = t_end if np.isnan(ts) else ts

            t99 = first_time_below(t, S, 0.01)
            if not np.isnan(t99):
                T99[i, j] = t99

    return Ara0_grid, alphaE_grid, Tsurv, T99


if __name__ == "__main__":
    p = Params()

 
    # Scenario A: automatic timed clearance (no Dox)
  
    t, Ara, E, F, F_free, S = simulate(p, Ara0=2.0, t_end=24*60)
    T_surv, t_kill_on, t_half = compute_metrics(t, F_free, S, p)
    print("Scenario A (auto, no Dox):")
    print(f"  T_survival (S<0.9): {T_surv:.1f} min")
    print(f"  kill onset (F_free>threshold): {t_kill_on:.1f} min")
    print(f"  kill half-life after onset: {t_half:.1f} min")
    plot_scenario(t, Ara, E, F_free, S, "Scenario A: automatic timed clearance (no Dox)")

 
    # Scenario B: emergency Dox clearance

    t_em = 8 * 60
    dox_level = 2.0
    t, Ara, E, F, F_free, S = simulate(p, Ara0=2.0, t_end=24*60, t_emergency=t_em, dox_level=dox_level)

    t99_abs = first_time_below(t[t >= t_em], S[t >= t_em], 0.01)
    T99_from_em = np.nan if np.isnan(t99_abs) else (t99_abs - t_em)
    print("\nScenario B (emergency Dox):")
    print(f"  T_99% after Dox (S<=0.01): {T99_from_em:.1f} min")
    plot_scenario(t, Ara, E, F_free, S, f"Scenario B: emergency Dox at {t_em} min (level={dox_level})")

   
    # Scenario C: operating space (no Dox)

    Ara0_grid = np.linspace(0.5, 5.0, 45)
    alphaE_grid = np.linspace(0.1, 1.2, 45)
    Ara0_grid, alphaE_grid, Tsurv, T99 = scan_operating_space(p, Ara0_grid, alphaE_grid, t_end=24*60)

    # survival window heatmap
    plt.figure(figsize=(7.8, 5.9))
    plt.imshow(
        Tsurv,
        origin="lower",
        aspect="auto",
        extent=[Ara0_grid[0], Ara0_grid[-1], alphaE_grid[0], alphaE_grid[-1]],
        vmin=0, vmax=24*60
    )
    plt.colorbar(label="T_survival (min) until S<0.9")
    plt.xlabel("[Ara]0")
    plt.ylabel("alpha_MazE (RBS strength proxy)")
    plt.title("Operating space: survival window (no Dox)")
    plt.tight_layout()
    plt.show()

    # kill reliability heatmap (mask NaN)
    T99m = np.ma.masked_invalid(T99)
    plt.figure(figsize=(7.8, 5.9))
    plt.imshow(
        T99m,
        origin="lower",
        aspect="auto",
        extent=[Ara0_grid[0], Ara0_grid[-1], alphaE_grid[0], alphaE_grid[-1]],
        vmin=0, vmax=24*60
    )
    plt.colorbar(label="Time to S<=0.01 (min); blank=not reached by 24h")
    plt.xlabel("[Ara]0")
    plt.ylabel("alpha_MazE (RBS strength proxy)")
    plt.title("Kill reliability: time to 99% kill (no Dox)")
    plt.tight_layout()
    plt.show()