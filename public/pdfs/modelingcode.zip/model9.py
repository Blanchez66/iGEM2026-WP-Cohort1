import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

def D_shell_from_pore(D0, RH_nm, R_pore_nm, lam=3.0):
    """D_shell = D0 * exp(-lam * RH/R_pore)."""
    return D0 * np.exp(-lam * (RH_nm / (R_pore_nm + 1e-12)))


# Parameters 

@dataclass
class Geometry:
    R_core: float = 0.35   # mm
    R_shell: float = 0.45  # mm
    R_out: float = 3.0     # mm
    Nr: int = 200          # nodes


@dataclass
class SpeciesParams:
    # base diffusivities (mm^2/min)
    D0_core: float = 6e-3
    D0_gel: float = 6e-3

    # pore model
    RH_nm: float = 0.5
    R_pore_nm: float = 8.0
    lam: float = 3.0

    # core source (uM/min, uniform in core)
    prod_core: float = 0.0

    # first-order decay (1/min)
    decay: float = 0.0

    # boundary type at r=R_out: "dirichlet" or "neumann0"
    bc_type: str = "neumann0"


@dataclass
class ModelParams:
    geo: Geometry = Geometry()
    AHL_ext: float = 1.0
    t_end: float = 600.0


# Grid + region helpers

def make_grid(geo: Geometry):
    r = np.linspace(0.0, geo.R_out, geo.Nr)
    dr = r[1] - r[0]
    return r, dr


def region_masks(r, geo: Geometry):
    core = r <= geo.R_core + 1e-12
    shell = (r > geo.R_core) & (r <= geo.R_shell + 1e-12)
    gel = r > geo.R_shell
    return core, shell, gel


def build_profiles(r, geo: Geometry, sp: SpeciesParams):
    core, shell, gel = region_masks(r, geo)
    D_shell = D_shell_from_pore(sp.D0_core, sp.RH_nm, sp.R_pore_nm, sp.lam)

    D = np.zeros_like(r)
    D[core] = sp.D0_core
    D[shell] = D_shell
    D[gel] = sp.D0_gel

    Rsrc = np.zeros_like(r)
    Rsrc[core] = sp.prod_core
    return D, D_shell, Rsrc


# Stable spherical diffusion: finite-volume form
# State variable C_i located at nodes r_i.
# Control volume i spans [r_{i-1/2}, r_{i+1/2}]

def diffusion_fvm_rhs(C, r, dr, D, bc_type, C_ext):
    Nr = len(r)
    C = np.maximum(C, 0.0)

    # face radii
    rf = np.zeros(Nr + 1)  # faces 0..Nr
    rf[1:-1] = (r[:-1] + r[1:]) / 2.0
    rf[0] = 0.0
    rf[-1] = r[-1]

    # cell volumes (without 4π/3 factor since it cancels consistently)
    V = (rf[1:]**3 - rf[:-1]**3) / 3.0
    V = np.maximum(V, 1e-30)

    # D at faces (harmonic mean)
    Df = np.zeros(Nr + 1)
    Df[1:-1] = 2 * D[:-1] * D[1:] / (D[:-1] + D[1:] + 1e-30)
    Df[0] = D[0]      # not used (symmetry)
    Df[-1] = D[-1]    # boundary face

    # impose boundary condition by setting ghost concentration
    if bc_type == "neumann0":
        Cghost = C[-1]  # zero gradient
    elif bc_type == "dirichlet":
        Cghost = float(C_ext)
    else:
        raise ValueError("bc_type must be 'neumann0' or 'dirichlet'")

    # fluxes at faces (omit 4π)
    F = np.zeros(Nr + 1)

    # inner boundary r=0: symmetry => F[0] = 0
    F[0] = 0.0

    # interior faces
    dC = (C[1:] - C[:-1]) / dr
    F[1:Nr] = - (rf[1:Nr]**2) * Df[1:Nr] * dC

    # outer face Nr: between last node and ghost
    dC_out = (Cghost - C[-1]) / dr
    F[Nr] = - (rf[Nr]**2) * Df[Nr] * dC_out

    # divergence to get dC/dt
    dCdt = (F[:-1] - F[1:]) / V
    return dCdt


# Simulation (3 species)

def simulate(model: ModelParams, AHL: SpeciesParams, PvdQ: SpeciesParams, Dye: SpeciesParams, AHL_ext_func=None):
    geo = model.geo
    r, dr = make_grid(geo)
    Nr = geo.Nr

    if AHL_ext_func is None:
        AHL_ext_func = lambda t: model.AHL_ext

    D_A, Dshell_A, R_A = build_profiles(r, geo, AHL)
    D_P, Dshell_P, R_P = build_profiles(r, geo, PvdQ)
    D_D, Dshell_D, R_D = build_profiles(r, geo, Dye)

    # ICs
    y0 = np.zeros(3 * Nr)

    def rhs(t, y):
        Ca = y[0:Nr]
        Cp = y[Nr:2*Nr]
        Cd = y[2*Nr:3*Nr]

        Aext = float(AHL_ext_func(t))

        dCa = diffusion_fvm_rhs(Ca, r, dr, D_A, AHL.bc_type, Aext) + R_A - AHL.decay * Ca
        dCp = diffusion_fvm_rhs(Cp, r, dr, D_P, PvdQ.bc_type, 0.0) + R_P - PvdQ.decay * Cp
        dCd = diffusion_fvm_rhs(Cd, r, dr, D_D, Dye.bc_type, 0.0) + R_D - Dye.decay * Cd

        # Hard clamp derivatives if NaN ever appears (prevents solver death spiral)
        out = np.concatenate([dCa, dCp, dCd])
        out[~np.isfinite(out)] = 0.0
        return out

    t_eval = np.linspace(0, model.t_end, 1201)
    sol = solve_ivp(rhs, (0, model.t_end), y0, t_eval=t_eval, method="BDF",
                    rtol=1e-6, atol=1e-9)
    if not sol.success:
        raise RuntimeError(sol.message)

    Ca = sol.y[0:Nr, :]
    Cp = sol.y[Nr:2*Nr, :]
    Cd = sol.y[2*Nr:3*Nr, :]

    return {
        "t": sol.t, "r": r, "dr": dr,
        "Ca": Ca, "Cp": Cp, "Cd": Cd,
        "Dshell_AHL": Dshell_A, "Dshell_PvdQ": Dshell_P, "Dshell_Dye": Dshell_D,
        "geo": geo
    }

# Metrics

def vol_avg_in_region(C_rt, r, mask):
    w = r[mask]**2
    w = w / np.sum(w)
    return (C_rt[mask, :].T @ w).T

def first_time_to_level(t, y, level):
    idx = np.where(y >= level)[0]
    return np.nan if len(idx) == 0 else float(t[idx[0]])


if __name__ == "__main__":
    model = ModelParams(geo=Geometry(R_core=0.35, R_shell=0.45, R_out=3.0, Nr=200),
                        AHL_ext=1.0, t_end=600.0)

    # AHL: small molecule
    AHL = SpeciesParams(
        D0_core=6e-3, D0_gel=6e-3,
        RH_nm=0.5, R_pore_nm=8.0, lam=3.0,
        prod_core=0.0, decay=0.001,
        bc_type="dirichlet"  # fixed external concentration at R_out
    )

    # PvdQ: large protein
    PvdQ = SpeciesParams(
        D0_core=1.2e-3, D0_gel=1.5e-3,
        RH_nm=3.0, R_pore_nm=8.0, lam=3.0,
        prod_core=0.015, decay=0.0005,
        bc_type="neumann0"
    )

    # Dye: intermediate
    Dye = SpeciesParams(
        D0_core=3e-3, D0_gel=3e-3,
        RH_nm=1.0, R_pore_nm=8.0, lam=3.0,
        prod_core=0.008, decay=0.0,
        bc_type="neumann0"
    )

    # External AHL step
    AHL_ext_func = lambda t: 1.0

    info = simulate(model, AHL, PvdQ, Dye, AHL_ext_func=AHL_ext_func)

    t, r, geo = info["t"], info["r"], info["geo"]
    Ca, Cp, Cd = info["Ca"], info["Cp"], info["Cd"]

    core_mask = r <= geo.R_core + 1e-12
    out_mask = r >= geo.R_shell + 1e-12

    print("Effective shell diffusivities (mm^2/min):")
    print(f"  D_AHL_shell  = {info['Dshell_AHL']:.3e}")
    print(f"  D_PvdQ_shell = {info['Dshell_PvdQ']:.3e}")
    print(f"  D_Dye_shell  = {info['Dshell_Dye']:.3e}")

    # ---- AHL penetration time ----
    A_core = vol_avg_in_region(Ca, r, core_mask)
    t50 = first_time_to_level(t, A_core, 0.5 * AHL_ext_func(0))
    t90 = first_time_to_level(t, A_core, 0.9 * AHL_ext_func(0))
    print(f"\nAHL core-avg t50≈{t50:.1f} min, t90≈{t90:.1f} min")

    plt.figure(figsize=(7.2, 4.4))
    plt.plot(t, A_core, lw=2, label="AHL core-avg")
    plt.axhline(0.5, color="gray", ls=":", lw=1)
    plt.axhline(0.9, color="gray", ls="--", lw=1)
    if np.isfinite(t50): plt.axvline(t50, color="k", ls=":", lw=1, label=f"t50={t50:.1f}")
    if np.isfinite(t90): plt.axvline(t90, color="k", ls="--", lw=1, label=f"t90={t90:.1f}")
    plt.xlabel("t (min)"); plt.ylabel("AHL (uM)")
    plt.title("AHL penetration into core (volume-averaged)")
    plt.grid(True, alpha=0.25); plt.legend()
    plt.tight_layout()
    plt.show()

    # ---- PvdQ outside build-up time ----
    P_out = vol_avg_in_region(Cp, r, out_mask)
    P_target = 0.5
    tP = first_time_to_level(t, P_out, P_target)
    print(f"PvdQ outside-avg reaches {P_target} uM at t≈{tP:.1f} min")

    plt.figure(figsize=(7.2, 4.4))
    plt.plot(t, P_out, lw=2, label="PvdQ outside-avg")
    plt.axhline(P_target, color="gray", ls="--", lw=1, label=f"target={P_target} uM")
    if np.isfinite(tP): plt.axvline(tP, color="k", ls="--", lw=1, label=f"t={tP:.1f}")
    plt.xlabel("t (min)"); plt.ylabel("PvdQ (uM)")
    plt.title("PvdQ release to outside gel (volume-averaged)")
    plt.grid(True, alpha=0.25); plt.legend()
    plt.tight_layout()
    plt.show()

    # ---- spatial snapshots ----
    snap_times = [10, 30, 60, 120, 300, 600]
    def tidx(ts): return int(np.argmin(np.abs(t - ts)))

    plt.figure(figsize=(8.0, 5.0))
    for ts in snap_times:
        plt.plot(r, Ca[:, tidx(ts)], lw=2, label=f"t={ts} min")
    plt.axvline(geo.R_core, color="k", ls=":", lw=1)
    plt.axvline(geo.R_shell, color="k", ls="--", lw=1)
    plt.xlabel("r (mm)"); plt.ylabel("AHL (uM)")
    plt.title("AHL radial profiles (core/shell boundaries marked)")
    plt.grid(True, alpha=0.25); plt.legend(ncol=2)
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(8.0, 5.0))
    for ts in snap_times:
        plt.plot(r, Cp[:, tidx(ts)], lw=2, label=f"t={ts} min")
    plt.axvline(geo.R_core, color="k", ls=":", lw=1)
    plt.axvline(geo.R_shell, color="k", ls="--", lw=1)
    plt.xlabel("r (mm)"); plt.ylabel("PvdQ (uM)")
    plt.title("PvdQ radial profiles")
    plt.grid(True, alpha=0.25); plt.legend(ncol=2)
    plt.tight_layout()
    plt.show()

    # ---- escape risk estimate ----
    RH_bacteria_nm = 1000.0  # ~1 µm
    D_bac_shell = D_shell_from_pore(D0=1e-3, RH_nm=RH_bacteria_nm, R_pore_nm=8.0, lam=3.0)
    print("\nEscape-risk check:")
    print(f"  If RH_bacteria≈1000 nm, predicted D_shell≈{D_bac_shell:.3e} mm^2/min (effectively zero)")