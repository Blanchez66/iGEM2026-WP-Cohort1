import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt


# Core: pH → release rate

@dataclass
class LipoParams:
    # Release rate sigmoid
    k_max: float = 0.08       # 1/min  (max release rate)
    pH_crit: float = 6.2      # critical pH (CHEMS pKa region)
    n_pH: float = 3.0         # steepness of sigmoid

    # Encapsulated PvdQ payload
    PvdQ_encap0: float = 10.0  # µM (total if all released)

    # (For comparison) non-pH-sensitive liposome: constant slow leak
    k_passive: float = 0.002   # 1/min


def k_release(pH: float, p: LipoParams) -> float:
    """pH-dependent release rate constant (1/min)."""
    return p.k_max / (1.0 + 10.0**(p.n_pH * (pH - p.pH_crit)))


# Part A: ODE at fixed pH

def rhs_ode(t, y, pH, p: LipoParams):
    I, PvdQ_r = y
    I = max(I, 0.0)
    PvdQ_r = max(PvdQ_r, 0.0)

    kr = k_release(pH, p)
    dI = -kr * I
    dPvdQ = kr * I * p.PvdQ_encap0
    return [dI, dPvdQ]


def simulate_ode(pH, p: LipoParams, t_end=300.0):
    t_eval = np.linspace(0, t_end, 1201)
    sol = solve_ivp(
        lambda t, y: rhs_ode(t, y, pH, p),
        (0, t_end), [1.0, 0.0],
        t_eval=t_eval, method="LSODA",
        rtol=1e-8, atol=1e-10
    )
    return sol.t, sol.y[0], sol.y[1]


def simulate_passive(p: LipoParams, t_end=300.0):
    """Non-pH-sensitive liposome: constant leak regardless of pH."""
    t_eval = np.linspace(0, t_end, 1201)
    sol = solve_ivp(
        lambda t, y: [-p.k_passive * max(y[0], 0),
                       p.k_passive * max(y[0], 0) * p.PvdQ_encap0],
        (0, t_end), [1.0, 0.0],
        t_eval=t_eval, method="LSODA",
        rtol=1e-8, atol=1e-10
    )
    return sol.t, sol.y[0], sol.y[1]


# Part B: 1-D radial PDE (method of lines)

@dataclass
class PDE_Params:
    R: float = 1.0          # mm  (airway half-width, wall at r=R, lumen centre at r=0)
    Nr: int = 100           # spatial grid points
    D_PvdQ: float = 5e-4    # mm²/min  diffusion coefficient

    # pH profile: acidic at wall (biofilm), neutral in lumen
    pH_wall: float = 5.8
    pH_lumen: float = 7.4
    biofilm_thickness: float = 0.15  # mm from wall

    # liposome density profile (concentrated near wall where inhaled particles deposit)
    lipo_peak_r: float = 0.85  # mm (close to wall)
    lipo_sigma: float = 0.08   # mm (Gaussian width)
    lipo_density: float = 1.0  # a.u. (relative)

    # PvdQ natural loss in tissue
    delta_PvdQ: float = 0.005  # 1/min


def pH_profile(r, pp: PDE_Params):
    """Smooth pH: acidic near wall (r→R), neutral in lumen (r→0)."""
    # Sigmoid transition at biofilm edge
    r_bio = pp.R - pp.biofilm_thickness
    steepness = 30.0  # 1/mm
    frac_acid = 1.0 / (1.0 + np.exp(-steepness * (r - r_bio)))
    return pp.pH_lumen + (pp.pH_wall - pp.pH_lumen) * frac_acid


def lipo_source(r, pp: PDE_Params):
    """Gaussian liposome density centered near wall."""
    return pp.lipo_density * np.exp(-0.5 * ((r - pp.lipo_peak_r)/pp.lipo_sigma)**2)


def build_pde_system(lp: LipoParams, pp: PDE_Params):
    Nr = pp.Nr
    dr = pp.R / (Nr - 1)
    r = np.linspace(0, pp.R, Nr)

    # Pre-compute pH(r), source(r), k_release(r)
    pH_r = np.array([pH_profile(ri, pp) for ri in r])
    kr_r = np.array([k_release(float(phi), lp) for phi in pH_r])
    src_r = lipo_source(r, pp)

    D = pp.D_PvdQ
    delta = pp.delta_PvdQ

    # States: [I_0..I_{Nr-1}, c_0..c_{Nr-1}]
    # I_i: liposome integrity at grid point i
    # c_i: free PvdQ concentration at grid point i

    def rhs_pde(t, y):
        I = y[:Nr]
        c = y[Nr:]

        # clamp
        I = np.clip(I, 0, 1)
        c = np.maximum(c, 0)

        dI = -kr_r * I

        # source: released PvdQ
        source = kr_r * I * src_r * lp.PvdQ_encap0

        # diffusion (second-order central difference)
        d2c = np.zeros(Nr)
        # interior
        d2c[1:-1] = (c[2:] - 2*c[1:-1] + c[:-2]) / dr**2
        # BC: no-flux at r=0 (symmetry) and r=R (wall)
        d2c[0] = 2*(c[1] - c[0]) / dr**2
        d2c[-1] = 2*(c[-2] - c[-1]) / dr**2

        dc = D * d2c + source - delta * c

        return np.concatenate([dI, dc])

    return r, pH_r, kr_r, rhs_pde


def simulate_pde(lp: LipoParams, pp: PDE_Params, t_end=300.0, nt_out=201):
    r, pH_r, kr_r, rhs_pde = build_pde_system(lp, pp)
    Nr = pp.Nr
    y0 = np.concatenate([np.ones(Nr), np.zeros(Nr)])
    t_eval = np.linspace(0, t_end, nt_out)

    sol = solve_ivp(
        rhs_pde, (0, t_end), y0,
        t_eval=t_eval, method="LSODA",
        rtol=1e-6, atol=1e-8
    )
    if not sol.success:
        raise RuntimeError(sol.message)

    I_xt = sol.y[:Nr, :]
    c_xt = sol.y[Nr:, :]
    return sol.t, r, pH_r, kr_r, I_xt, c_xt


# Main: produce all assignment figures

if __name__ == "__main__":
    lp = LipoParams()
    pp = PDE_Params()
    
    # Figure 1: pH–release rate curve (sigmoid)
   
    pH_arr = np.linspace(4.5, 8.0, 300)
    kr_arr = np.array([k_release(ph, lp) for ph in pH_arr])

    plt.figure(figsize=(6.5, 4.2))
    plt.plot(pH_arr, kr_arr, lw=2)
    plt.axvline(lp.pH_crit, ls="--", color="gray", lw=1,
                label=f"pH_crit = {lp.pH_crit}")
    plt.xlabel("pH")
    plt.ylabel("k_release (1/min)")
    plt.title("pH-dependent release rate constant (CHEMS/DOPE liposome)")
    plt.grid(True, alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.show()

    
    # Figure 2: release time course at different pHs
 
    pH_list = [5.5, 6.0, 6.5, 7.0, 7.4]
    colors = plt.cm.coolwarm(np.linspace(0, 1, len(pH_list)))

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))

    for pH_val, col in zip(pH_list, colors):
        t, I, PvdQ = simulate_ode(pH_val, lp, t_end=300)
        axes[0].plot(t, I, lw=2, color=col, label=f"pH {pH_val}")
        axes[1].plot(t, PvdQ, lw=2, color=col, label=f"pH {pH_val}")

    axes[0].set_xlabel("t (min)"); axes[0].set_ylabel("Integrity I(t)")
    axes[0].set_title("Liposome integrity vs time")
    axes[0].grid(True, alpha=0.25); axes[0].legend()

    axes[1].set_xlabel("t (min)"); axes[1].set_ylabel("PvdQ released (µM)")
    axes[1].set_title("Cumulative PvdQ release vs time")
    axes[1].grid(True, alpha=0.25); axes[1].legend()
    plt.tight_layout()
    plt.show()

    
    # Figure 3: selectivity — pH-sensitive vs passive liposome
    
    t_pass, I_pass, PvdQ_pass = simulate_passive(lp, t_end=300)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))

    # Acidic (infected tissue, pH 5.8)
    t_acid, I_acid, PvdQ_acid = simulate_ode(5.8, lp, t_end=300)
    axes[0].plot(t_acid, PvdQ_acid, lw=2, label="pH-sensitive @ pH 5.8")
    axes[0].plot(t_pass, PvdQ_pass, lw=2, ls="--", label="Passive @ any pH")
    axes[0].set_title("Infected tissue (pH 5.8)")
    axes[0].set_xlabel("t (min)"); axes[0].set_ylabel("PvdQ released (µM)")
    axes[0].grid(True, alpha=0.25); axes[0].legend()

    # Neutral (healthy tissue, pH 7.4)
    t_neut, I_neut, PvdQ_neut = simulate_ode(7.4, lp, t_end=300)
    axes[1].plot(t_neut, PvdQ_neut, lw=2, label="pH-sensitive @ pH 7.4")
    axes[1].plot(t_pass, PvdQ_pass, lw=2, ls="--", label="Passive @ any pH")
    axes[1].set_title("Healthy tissue (pH 7.4)")
    axes[1].set_xlabel("t (min)"); axes[1].set_ylabel("PvdQ released (µM)")
    axes[1].grid(True, alpha=0.25); axes[1].legend()

    plt.suptitle("Selectivity: pH-sensitive vs passive liposome", y=1.02, fontsize=13)
    plt.tight_layout()
    plt.show()

    # Compute selectivity ratio at t=120 min
    PvdQ_acid_120 = np.interp(120, t_acid, PvdQ_acid)
    PvdQ_neut_120 = np.interp(120, t_neut, PvdQ_neut)
    PvdQ_pass_120 = np.interp(120, t_pass, PvdQ_pass)
    ratio = PvdQ_acid_120 / max(PvdQ_neut_120, 1e-6)
    print(f"Selectivity at 120 min: PvdQ(pH5.8)/PvdQ(pH7.4) = {ratio:.1f}x")
    print(f"  pH-sensitive @ pH5.8: {PvdQ_acid_120:.2f} µM")
    print(f"  pH-sensitive @ pH7.4: {PvdQ_neut_120:.4f} µM")
    print(f"  Passive @ 120 min:    {PvdQ_pass_120:.2f} µM")

    
    # Figure 4: parameter scan — optimal pH_crit & n_pH
  
    pH_crit_grid = np.linspace(5.5, 7.0, 40)
    n_pH_grid = np.linspace(1.0, 6.0, 40)
    selectivity = np.zeros((len(n_pH_grid), len(pH_crit_grid)))

    for i, n_val in enumerate(n_pH_grid):
        for j, pc in enumerate(pH_crit_grid):
            lp2 = LipoParams(pH_crit=pc, n_pH=n_val)
            _, _, Pa = simulate_ode(5.8, lp2, t_end=120)
            _, _, Pn = simulate_ode(7.4, lp2, t_end=120)
            selectivity[i, j] = Pa[-1] / max(Pn[-1], 1e-6)

    plt.figure(figsize=(7.8, 5.8))
    plt.imshow(
        selectivity,
        origin="lower",
        aspect="auto",
        extent=[pH_crit_grid[0], pH_crit_grid[-1],
                n_pH_grid[0], n_pH_grid[-1]]
    )
    plt.colorbar(label="Selectivity (PvdQ at pH5.8 / pH7.4 at 120 min)")
    plt.xlabel("pH_crit")
    plt.ylabel("n_pH (steepness)")
    plt.title("Parameter scan: selectivity of pH-sensitive liposome")
    plt.tight_layout()
    plt.show()

   
    # Figure 5: 1-D spatial PDE — PvdQ concentration heatmap in airway
   
    t_pde, r_pde, pH_r, kr_r, I_xt, c_xt = simulate_pde(lp, pp, t_end=300, nt_out=301)

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    # pH profile
    axes[0].plot(r_pde, pH_r, lw=2, color="C3")
    axes[0].set_xlabel("r (mm, 0=lumen, R=wall)")
    axes[0].set_ylabel("pH")
    axes[0].set_title("pH profile across airway")
    axes[0].grid(True, alpha=0.25)

    # PvdQ heatmap
    im = axes[1].pcolormesh(r_pde, t_pde, c_xt.T, shading="auto", cmap="inferno")
    plt.colorbar(im, ax=axes[1], label="[PvdQ] (µM)")
    axes[1].set_xlabel("r (mm)")
    axes[1].set_ylabel("t (min)")
    axes[1].set_title("PvdQ(r,t) in airway cross-section")

    # Snapshots
    snap_times = [30, 60, 120, 240]
    for ts in snap_times:
        idx = np.argmin(np.abs(t_pde - ts))
        axes[2].plot(r_pde, c_xt[:, idx], lw=2, label=f"t={ts} min")
    axes[2].set_xlabel("r (mm)")
    axes[2].set_ylabel("[PvdQ] (µM)")
    axes[2].set_title("PvdQ spatial snapshots")
    axes[2].grid(True, alpha=0.25)
    axes[2].legend()

    plt.suptitle("1-D radial PDE: pH-triggered PvdQ release in airway", y=1.02, fontsize=13)
    plt.tight_layout()
    plt.show()