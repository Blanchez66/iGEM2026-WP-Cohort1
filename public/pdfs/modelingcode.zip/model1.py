import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt


# 1) Parameters

@dataclass
class Params:
    # sensing layer
    alpha_AbaR: float = 5.0      # nM/min
    gamma_AbaR: float = 0.02     # 1/min

    k_in: float = 1.0            # 1/min  (AHLext -> AHLint)
    k_out: float = 1.0           # 1/min  (AHLint -> AHLext)

    k_on: float = 1e6 / 1e9 * 60   # ~0.06 nM^-1 min^-1
    k_off: float = 1e-2 * 60       # 0.6 1/min

    gamma_c: float = 0.02        # 1/min

    # pAbaI* -> T7
    alpha_T7: float = 50.0       # nM/min
    beta_T7: float = 0.1         # nM/min (leak)
    gamma_T7: float = 0.02       # 1/min
    Kd_pAbaI: float = 50.0       # nM
    n_hill: float = 2.0

    # pT7 -> PvdQ
    alpha_PvdQ: float = 100.0    # nM/min
    beta_PvdQ: float = 0.1       # nM/min (leak)
    gamma_PvdQ: float = 0.01     # 1/min
    Kd_pT7: float = 20.0         # nM
    m_hill: float = 2.0


def hill(x, K, n):
    x = max(x, 0.0)
    return (x**n) / (K**n + x**n + 1e-12)


def ode_rhs(t, y, p: Params, AHL_ext_func):
    AbaR, AHL_int, Cplx, T7, PvdQ = y
    AHL_ext = AHL_ext_func(t)

    dAbaR = (p.alpha_AbaR
             - p.gamma_AbaR * AbaR
             - p.k_on * AbaR * AHL_int
             + p.k_off * Cplx)

    dAHLint = (p.k_in * AHL_ext
               - p.k_out * AHL_int
               - p.k_on * AbaR * AHL_int
               + p.k_off * Cplx)

    dCplx = (p.k_on * AbaR * AHL_int
             - p.k_off * Cplx
             - p.gamma_c * Cplx)

    dT7 = (p.alpha_T7 * hill(Cplx, p.Kd_pAbaI, p.n_hill)
           + p.beta_T7
           - p.gamma_T7 * T7)

    dPvdQ = (p.alpha_PvdQ * hill(T7, p.Kd_pT7, p.m_hill)
             + p.beta_PvdQ
             - p.gamma_PvdQ * PvdQ)

    return [dAbaR, dAHLint, dCplx, dT7, dPvdQ]



# 2) Input function: step in AHL_ext

def make_step_AHL(AHL0=0.0, AHL1=50.0, t_step=0.0):
    def f(t):
        return AHL0 if t < t_step else AHL1
    return f


# 3) Simulation utilities: run, extract steady state, compute t90

def simulate(p: Params, AHL_ext_func, t_end=600, y0=None, n_points=2001):
    if y0 is None:
        y0 = np.zeros(5)  # [AbaR, AHLint, Cplx, T7, PvdQ]
    t_eval = np.linspace(0, t_end, n_points)
    sol = solve_ivp(
        fun=lambda t, y: ode_rhs(t, y, p, AHL_ext_func),
        t_span=(0, t_end),
        y0=y0,
        t_eval=t_eval,
        method="LSODA",
        rtol=1e-6,
        atol=1e-9
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.t, sol.y


def steady_state_from_sim(t, y, tail_frac=0.1):
    # Approximate steady state by averaging over the last 10% of the time window
    n = len(t)
    i0 = int((1 - tail_frac) * n)
    return np.mean(y[:, i0:], axis=1)


def t90(t, signal, steady_value=None, baseline=None):
    if baseline is None:
        baseline = signal[0]
    if steady_value is None:
        steady_value = signal[-1]
    target = baseline + 0.9 * (steady_value - baseline)
    # Find the first time the signal reaches the target
    idx = np.where(signal >= target)[0]
    return np.nan if len(idx) == 0 else t[idx[0]]



# 4) (A) Example step response + t90

if __name__ == "__main__":
    p = Params()

    AHL_ext = make_step_AHL(AHL0=0.0, AHL1=10.0, t_step=0.0)  # nM
    t, y = simulate(p, AHL_ext, t_end=600)  # min

    AbaR, AHL_int, Cplx, T7, PvdQ = y
    ss = steady_state_from_sim(t, y)
    t90_pvdq = t90(t, PvdQ, steady_value=ss[4], baseline=PvdQ[0])

    print("Approx steady states [AbaR, AHLint, Cplx, T7, PvdQ] (nM):")
    print(np.round(ss, 3))
    print(f"t90(PvdQ) ≈ {t90_pvdq:.1f} min")

    plt.figure(figsize=(8, 5))
    plt.plot(t, Cplx, label="AbaR:AHL")
    plt.plot(t, T7, label="T7")
    plt.plot(t, PvdQ, label="PvdQ")
    plt.xlabel("Time (min)")
    plt.ylabel("Concentration (nM)")
    plt.title("Step response")
    plt.legend()
    plt.tight_layout()
    plt.show()

  
    # 4) (B) Steady-state dose–response curve: PvdQ_ss vs AHL_ext
 
    AHL_grid = np.logspace(-2, 3, 40)  # 0.01 ~ 1000 nM
    PvdQ_ss = []

    # To speed up convergence: use the previous input's steady state as the next initial condition (continuation)
    y0 = np.zeros(5)
    for A in AHL_grid:
        AHL_const = lambda t, A=A: A
        t1, y1 = simulate(p, AHL_const, t_end=800, y0=y0, n_points=1501)
        ss1 = steady_state_from_sim(t1, y1)
        PvdQ_ss.append(ss1[4])
        y0 = ss1  # warm-start

    PvdQ_ss = np.array(PvdQ_ss)

    plt.figure(figsize=(7, 4.5))
    plt.semilogx(AHL_grid, PvdQ_ss, "-o", ms=3)
    plt.xlabel("[AHL_ext] (nM)")
    plt.ylabel("PvdQ steady state (nM)")
    plt.title("Dose–response (steady state)")
    plt.tight_layout()
    plt.show()

    
    # 4) (C) Simple parameter scan example: scan Kd_pAbaI and alpha_AbaR, evaluate PvdQ_ss
  
    Kd_vals = np.logspace(0, 2.7, 25)     # 1 ~ ~500 nM
    aR_vals = np.logspace(-1, 1.2, 25)    # 0.1 ~ ~16 nM/min
    AHL_test = 10.0  # nM, fix one test input

    Z = np.zeros((len(aR_vals), len(Kd_vals)))

    for i, aR in enumerate(aR_vals):
        for j, Kd in enumerate(Kd_vals):
            p2 = Params(**{**p.__dict__, "alpha_AbaR": float(aR), "Kd_pAbaI": float(Kd)})
            AHL_const = lambda t, A=AHL_test: A
            t2, y2 = simulate(p2, AHL_const, t_end=800, y0=np.zeros(5), n_points=1201)
            ss2 = steady_state_from_sim(t2, y2)
            Z[i, j] = ss2[4]  # PvdQ_ss

    plt.figure(figsize=(8, 5))
    im = plt.imshow(
        Z,
        origin="lower",
        aspect="auto",
        extent=[np.log10(Kd_vals[0]), np.log10(Kd_vals[-1]), np.log10(aR_vals[0]), np.log10(aR_vals[-1])]
    )
    plt.colorbar(im, label="PvdQ_ss (nM)")
    plt.xlabel("log10(Kd_pAbaI) (nM)")
    plt.ylabel("log10(alpha_AbaR) (nM/min)")
    plt.title(f"Parameter scan at [AHL_ext]={AHL_test} nM")
    plt.tight_layout()
    plt.show()