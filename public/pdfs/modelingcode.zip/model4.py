import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt


@dataclass
class Params:
    # Domain/grid
    L: float = 1.0          # domain length (a.u.)
    Nx: int = 201           # grid points

    # Bacteria dynamics
    Db: float = 2e-4        # bacterial diffusion (a.u.^2/min)
    mu_b: float = 0.01      # growth rate (1/min)
    bmax: float = 1.0       # carrying capacity (density units)

    # AHL dynamics
    Dc: float = 5e-4        # AHL diffusion (a.u.^2/min)
    rAHL: float = 0.02      # AHL production strength (uM/min, scaled)
    delta_c: float = 0.002  # AHL natural loss (1/min)

    # Chemotaxis sensitivity chi(c) = chi0 * Kd/(Kd+c)^2
    chi0: float = 5e-4      # max chemotaxis sensitivity (a.u.^2/(min*uM))
    Kd: float = 0.5         # uM

    # PvdQ degradation (lumped): rate = kdeg * b * c/(Km + c)
    # (Here we approximate [PvdQ] ~ proportional to local b)
    kdeg: float = 0.08      # 1/min (scaled)
    Km: float = 1.0         # uM

    # Biofilm / CRAB source geometry in 1D
    x0: float = 0.75        # biofilm center
    w: float = 0.06         # biofilm half-width (source region)


def chi_of_c(c, p: Params):
    return p.chi0 * (p.Kd / (p.Kd + c)**2)

def rho_crab(x, p: Params):
    # simple "top-hat" biofilm source region
    return ((x >= (p.x0 - p.w)) & (x <= (p.x0 + p.w))).astype(float)

def tef(b, x, p: Params):
    # TEF = (fraction of b in biofilm region)/(volume fraction of region)
    mask = (x >= (p.x0 - p.w)) & (x <= (p.x0 + p.w))
    dx = x[1] - x[0]
    B_bio = np.sum(b[mask]) * dx
    B_tot = np.sum(b) * dx
    frac_bio = B_bio / (B_tot + 1e-12)
    frac_vol = (np.sum(mask) * dx) / (x[-1] - x[0] + dx)
    return frac_bio / (frac_vol + 1e-12)

def rhs_mol(t, y, p: Params, x):
    """
    Method of lines for 1D PDEs.
    y = [b0..bN-1, c0..cN-1]
    """
    Nx = p.Nx
    b = y[:Nx].copy()
    c = y[Nx:].copy()
    dx = x[1] - x[0]

    # Enforce nonnegativity softly (prevents blow-ups in deg term)
    b = np.maximum(b, 0.0)
    c = np.maximum(c, 0.0)

    # Diffusion terms with Neumann BC via ghost-cell reflection 
    def laplacian_neumann(u):
        uL = np.r_[u[1], u, u[-2]]  # reflect endpoints
        return (uL[:-2] - 2*uL[1:-1] + uL[2:]) / dx**2

    b_xx = laplacian_neumann(b)
    c_xx = laplacian_neumann(c)

    # Chemotaxis term: -d/dx( chi(c) * b * dc/dx ) with no-flux at boundaries 
    # Compute dc/dx at cell faces (i+1/2)
    cL = np.r_[c[1], c, c[-2]]
    dc_dx_center = (cL[2:] - cL[:-2]) / (2*dx)  # at centers (same length Nx)

    # Face gradients using central difference on faces
    dc_dx_face = (c[1:] - c[:-1]) / dx  # length Nx-1

    # chi at faces (average)
    chi_center = chi_of_c(c, p)
    chi_face = 0.5 * (chi_center[1:] + chi_center[:-1])

    # b at faces (average)
    b_face = 0.5 * (b[1:] + b[:-1])

    # chemotactic flux at faces
    J_face = chi_face * b_face * dc_dx_face  # length Nx-1

    # impose no-flux at boundaries: J_{-1/2}=J_{N-1/2}=0
    # divergence at centers: (J_{i+1/2}-J_{i-1/2})/dx
    divJ = np.zeros_like(b)
    divJ[1:-1] = (J_face[1:] - J_face[:-1]) / dx
    divJ[0] = (J_face[0] - 0.0) / dx
    divJ[-1] = (0.0 - J_face[-1]) / dx

    #  Growth term 
    growth = p.mu_b * b * (1.0 - b / p.bmax)

    #  AHL source and degradation 
    source = p.rAHL * rho_crab(x, p)
    deg = p.kdeg * b * c / (p.Km + c + 1e-12)

    db_dt = p.Db * b_xx - divJ + growth
    dc_dt = p.Dc * c_xx + source - deg - p.delta_c * c

    return np.r_[db_dt, dc_dt]


def run_sim(p: Params, t_end=800.0, chi0_override=None):
    x = np.linspace(0, p.L, p.Nx)

    # initial conditions: uniform low bacteria, AHL initially low
    b0 = 0.05 * np.ones(p.Nx)
    c0 = 0.0 * np.ones(p.Nx)

    # small bump of bacteria away from biofilm to show migration
    b0 += 0.02 * np.exp(-((x - 0.2)/0.07)**2)

    p_use = Params(**p.__dict__)
    if chi0_override is not None:
        p_use.chi0 = float(chi0_override)

    y0 = np.r_[b0, c0]

    # non-uniform time sampling: denser early
    t_eval = np.unique(np.r_[np.linspace(0, 120, 601), np.linspace(120, t_end, 500)])

    sol = solve_ivp(
        fun=lambda t, y: rhs_mol(t, y, p_use, x),
        t_span=(0, t_end),
        y0=y0,
        method="LSODA",
        t_eval=t_eval,
        rtol=1e-6,
        atol=1e-9
    )
    if not sol.success:
        raise RuntimeError(sol.message)

    # reshape outputs: (Nt, Nx)
    Nt = sol.t.size
    b = sol.y[:p.Nx, :].T
    c = sol.y[p.Nx:, :].T

    # TEF over time
    tef_t = np.array([tef(b[i], x, p_use) for i in range(Nt)])

    return x, sol.t, b, c, tef_t, p_use


def plot_results(x, t, b, c, tef_t, p: Params, title_suffix=""):
    # heatmaps
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.2))

    im0 = ax[0].imshow(
        b, aspect="auto", origin="lower",
        extent=[x[0], x[-1], t[0], t[-1]]
    )
    ax[0].set_title(f"b(x,t) EcN density{title_suffix}")
    ax[0].set_xlabel("x"); ax[0].set_ylabel("t (min)")
    plt.colorbar(im0, ax=ax[0], fraction=0.046)

    im1 = ax[1].imshow(
        c, aspect="auto", origin="lower",
        extent=[x[0], x[-1], t[0], t[-1]]
    )
    ax[1].set_title(f"c(x,t) AHL (uM){title_suffix}")
    ax[1].set_xlabel("x"); ax[1].set_ylabel("t (min)")
    plt.colorbar(im1, ax=ax[1], fraction=0.046)

    ax[2].plot(t, tef_t, lw=2)
    ax[2].set_title(f"TEF vs time{title_suffix}")
    ax[2].set_xlabel("t (min)")
    ax[2].set_ylabel("TEF")
    ax[2].grid(True, alpha=0.25)

    # mark biofilm region
    for a in ax[:2]:
        a.axvline(p.x0 - p.w, color="w", lw=1, ls="--", alpha=0.8)
        a.axvline(p.x0 + p.w, color="w", lw=1, ls="--", alpha=0.8)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    p = Params()

    # Case A: no chemotaxis
    x0, t0, b0, c0, tef0, p0 = run_sim(p, t_end=800, chi0_override=0.0)

    # Case B: with chemotaxis
    x1, t1, b1, c1, tef1, p1 = run_sim(p, t_end=800, chi0_override=p.chi0)

    # Plot heatmaps + TEF
    plot_results(x0, t0, b0, c0, tef0, p0, title_suffix=" (no chemotaxis)")
    plot_results(x1, t1, b1, c1, tef1, p1, title_suffix=" (with chemotaxis)")

    # Overlay TEF comparison
    plt.figure(figsize=(7, 4.2))
    plt.plot(t0, tef0, lw=2, label="no chemotaxis (chi0=0)")
    plt.plot(t1, tef1, lw=2, label=f"chemotaxis (chi0={p.chi0:g})")
    plt.xlabel("t (min)")
    plt.ylabel("TEF")
    plt.title("Targeting Enrichment Factor (TEF) comparison")
    plt.grid(True, alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.show()