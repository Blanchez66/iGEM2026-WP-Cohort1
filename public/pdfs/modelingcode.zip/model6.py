import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter


# Competitive MM rates

@dataclass
class CompParams:
    # Enzyme level (lumped constant)
    PvdQ_uM: float = 0.01

    # Substrate affinities (design: Km_AHL << Km_Probe)
    Km_AHL: float = 1.0      # uM
    Km_Probe: float = 50.0   # uM

    # Turnover (moderate to avoid instant saturation)
    kcat_AHL_s: float = 5.0     # 1/s
    kcat_Probe_s: float = 0.2   # 1/s

    # Optional losses
    delta_Probe: float = 0.0  # 1/min
    delta_Dye: float = 0.0    # 1/min

    yield_dye: float = 1.0    # probe -> dye


def v_competitive(AHL_uM, Probe_uM, p: CompParams):
    """Return v_AHL and v_Probe in uM/min under competitive substrate kinetics."""
    A = max(float(AHL_uM), 0.0)
    S = max(float(Probe_uM), 0.0)

    kcatA = p.kcat_AHL_s * 60.0
    kcatP = p.kcat_Probe_s * 60.0
    E = p.PvdQ_uM

    vA = (kcatA * E * A) / (p.Km_AHL * (1.0 + S / (p.Km_Probe + 1e-12)) + A + 1e-12)
    vP = (kcatP * E * S) / (p.Km_Probe * (1.0 + A / (p.Km_AHL + 1e-12)) + S + 1e-12)
    return vA, vP


# Generic readout: Probe -> Dye with AHL treated as external input AHL(t)
# States: [Probe, Dye]

def rhs_probe_dye(t, y, p: CompParams, AHL_of_t):
    Probe, Dye = y
    Probe = max(Probe, 0.0)
    Dye = max(Dye, 0.0)

    A = max(float(AHL_of_t(t)), 0.0)
    _, vP = v_competitive(A, Probe, p)

    dProbe = -vP - p.delta_Probe * Probe
    dDye = p.yield_dye * vP - p.delta_Dye * Dye
    return [dProbe, dDye]


def simulate_probe_dye(p: CompParams, AHL_of_t, Probe0=20.0, Dye0=0.0, t_end=600.0):
    t_eval = np.unique(np.r_[np.linspace(0, min(60, t_end), 1201),
                             np.linspace(min(60, t_end), t_end, 801)])
    sol = solve_ivp(
        fun=lambda t, y: rhs_probe_dye(t, y, p, AHL_of_t),
        t_span=(0, t_end),
        y0=[Probe0, Dye0],
        t_eval=t_eval,
        method="LSODA",
        rtol=1e-7,
        atol=1e-10
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.t, sol.y[0], sol.y[1]


def first_crossing_time(t, y, thr):
    idx = np.where(y >= thr)[0]
    return np.nan if len(idx) == 0 else float(t[idx[0]])


# Wound module: cI-ssrA -> BpsA -> pigment (AHL can be external)
# States: [cI, BpsA, Pigment]

@dataclass
class WoundParams:
    alpha_cI: float = 0.5     # uM/min
    Kd_AHL: float = 1.0       # uM
    n: float = 2.0
    gamma_cI: float = 0.02    # 1/min
    gamma_ssrA: float = 0.05  # 1/min

    alpha_BpsA: float = 0.3   # uM/min
    K_R_cI: float = 0.5       # uM
    n_R: float = 2.0
    gamma_BpsA: float = 0.02  # 1/min

    k_pig: float = 0.4        # 1/min per uM BpsA
    delta_pig: float = 0.01   # 1/min (added to avoid unbounded growth)


def hill(x, K, n):
    x = max(float(x), 0.0)
    return (x**n) / (K**n + x**n + 1e-12)


def rhs_wound(t, y, wp: WoundParams, AHL_of_t):
    cI, BpsA, Pig = y
    cI = max(cI, 0.0); BpsA = max(BpsA, 0.0); Pig = max(Pig, 0.0)

    A = max(float(AHL_of_t(t)), 0.0)

    prod_cI = wp.alpha_cI * hill(A, wp.Kd_AHL, wp.n)
    dcI = prod_cI - (wp.gamma_cI + wp.gamma_ssrA) * cI

    rep = (wp.K_R_cI**wp.n_R) / (wp.K_R_cI**wp.n_R + cI**wp.n_R + 1e-12)
    dBpsA = wp.alpha_BpsA * rep - wp.gamma_BpsA * BpsA

    dPig = wp.k_pig * BpsA - wp.delta_pig * Pig
    return [dcI, dBpsA, dPig]


def simulate_wound(wp: WoundParams, AHL_of_t, t_end=600.0):
    y0 = [0.0, 0.0, 0.0]
    t_eval = np.unique(np.r_[np.linspace(0, min(60, t_end), 1201),
                             np.linspace(min(60, t_end), t_end, 801)])
    sol = solve_ivp(
        fun=lambda t, y: rhs_wound(t, y, wp, AHL_of_t),
        t_span=(0, t_end),
        y0=y0,
        t_eval=t_eval,
        method="LSODA",
        rtol=1e-7,
        atol=1e-10
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    cI, BpsA, Pig = sol.y
    return sol.t, cI, BpsA, Pig



# Blood module: PEG-probe -> active by CpaA -> dye by PvdQ under competition with AHL(t)
# States: [Probe_PEG, Probe_active, Dye]

@dataclass
class BloodParams:
    CpaA_uM: float = 0.2
    k_CpaA: float = 0.01      # 1/(min*uM) slower activation -> visible active hump
    delta_active: float = 0.0 # 1/min extra loss


def rhs_blood(t, y, p: CompParams, bp: BloodParams, AHL_of_t):
    PEG, Act, Dye = y
    PEG = max(PEG, 0.0); Act = max(Act, 0.0); Dye = max(Dye, 0.0)

    A = max(float(AHL_of_t(t)), 0.0)
    _, vP = v_competitive(A, Act, p)

    act = bp.k_CpaA * bp.CpaA_uM * PEG

    dPEG = -act
    dAct = act - vP - bp.delta_active * Act - p.delta_Probe * Act
    dDye = p.yield_dye * vP - p.delta_Dye * Dye
    return [dPEG, dAct, dDye]


def simulate_blood(p: CompParams, bp: BloodParams, AHL_of_t, PEG0=30.0, Act0=0.0, Dye0=0.0, t_end=600.0):
    t_eval = np.unique(np.r_[np.linspace(0, min(60, t_end), 1201),
                             np.linspace(min(60, t_end), t_end, 801)])
    sol = solve_ivp(
        fun=lambda t, y: rhs_blood(t, y, p, bp, AHL_of_t),
        t_span=(0, t_end),
        y0=[PEG0, Act0, Dye0],
        t_eval=t_eval,
        method="LSODA",
        rtol=1e-7,
        atol=1e-10
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    PEG, Act, Dye = sol.y
    return sol.t, PEG, Act, Dye


# Plot helpers (disable offset formatting)

def no_offset(ax):
    ax.yaxis.set_major_formatter(ScalarFormatter(useOffset=False))
    ax.ticklabel_format(axis="y", style="plain", useOffset=False)


# Main: produce the 4 figures (dose-response, timeline, blood, wound ssrA scan)

if __name__ == "__main__":
    cp = CompParams(
        PvdQ_uM=0.01,
        Km_AHL=1.0,
        Km_Probe=50.0,
        kcat_AHL_s=5.0,
        kcat_Probe_s=0.2
    )

    # (1) Dose-response: AHL is CLAMPED constant over time
    Probe0 = 20.0
    t_end_dose = 120.0
    dye_detect = 1.0  # detection threshold at 120 min (tune to your reporter)
    Agrid = np.logspace(-3, 2, 80)

    Dye_end = np.zeros_like(Agrid)
    for i, A0 in enumerate(Agrid):
        AHL_const = lambda t, A0=A0: A0
        t, Probe, Dye = simulate_probe_dye(cp, AHL_const, Probe0=Probe0, t_end=t_end_dose)
        Dye_end[i] = Dye[-1]

    # critical AHL where Dye_end crosses detection threshold (ON when Dye_end >= dye_detect)
    on = Dye_end >= dye_detect
    AHLcrit = np.nan
    if np.any(on):
        AHLcrit = float(Agrid[np.where(on)[0][0]])

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.semilogx(Agrid, Dye_end, lw=2)
    if np.isfinite(AHLcrit):
        ax.axvline(AHLcrit, color="k", ls="--", lw=1, label=f"AHLcrit≈{AHLcrit:.3g} µM")
    ax.axhline(dye_detect, color="gray", ls=":", lw=1, label=f"detection={dye_detect:g} µM")
    ax.set_xlabel("Initial AHL (µM)  [clamped]")
    ax.set_ylabel(f"Dye at {t_end_dose:.0f} min (µM)")
    ax.set_title("Dose-response: AHL vs color output (competitive kinetics)")
    ax.grid(True, alpha=0.25)
    no_offset(ax)
    ax.legend()
    plt.tight_layout()
    plt.show()

    # (2) Timeline: prescribe AHL(t) decay to create a color delay window
    AHL0 = 10.0
    AHL_floor = 0.02
    k_clear = 0.02  # 1/min, larger -> faster AHL drop -> earlier color
    AHL_decay = lambda t: AHL_floor + (AHL0 - AHL_floor) * np.exp(-k_clear * t)

    t, Probe, Dye = simulate_probe_dye(cp, AHL_decay, Probe0=Probe0, t_end=600.0)
    A_t = np.array([AHL_decay(tt) for tt in t])

    dye_thr_time = first_crossing_time(t, Dye, thr=dye_detect)

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.plot(t, A_t, lw=2, label="AHL(t) (external)")
    ax.plot(t, Dye, lw=2, label="Dye (from Probe)")
    ax.axhline(dye_detect, color="gray", ls=":", lw=1)
    if np.isfinite(dye_thr_time):
        ax.axvline(dye_thr_time, color="k", ls="--", lw=1, label=f"t_color≈{dye_thr_time:.1f} min")
    ax.set_xlabel("t (min)")
    ax.set_ylabel("µM")
    ax.set_title("Timeline: AHL decreases -> Probe cleavage increases (competition)")
    ax.grid(True, alpha=0.25)
    no_offset(ax)
    ax.legend()
    plt.tight_layout()
    plt.show()

    # (3) Blood module: CpaA activates PEG probe; PvdQ cleaves active probe 
    bp = BloodParams(CpaA_uM=0.2, k_CpaA=0.01)
    t, PEG, Act, Dye_b = simulate_blood(cp, bp, AHL_decay, PEG0=30.0, t_end=600.0)

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.plot(t, PEG, lw=2, label="Probe_PEG (inactive)")
    ax.plot(t, Act, lw=2, label="Probe_active")
    ax.plot(t, Dye_b, lw=2, label="Dye")
    ax.set_xlabel("t (min)")
    ax.set_ylabel("µM")
    ax.set_title("Blood module: CpaA activation + competitive PvdQ cleavage")
    ax.grid(True, alpha=0.25)
    no_offset(ax)
    ax.legend()
    plt.tight_layout()
    plt.show()

    # (4) Wound module: ssrA scan (AHL low -> pigment rises faster with higher gamma_ssrA) 
    wp_base = WoundParams()
    gammas = [0.0, 0.03, 0.08, 0.15]

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    for g in gammas:
        wp = WoundParams(**{**wp_base.__dict__, "gamma_ssrA": g})
        t, cI, BpsA, Pig = simulate_wound(wp, AHL_decay, t_end=600.0)
        ax.plot(t, Pig, lw=2, label=f"gamma_ssrA={g:g}/min")
    ax.set_xlabel("t (min)")
    ax.set_ylabel("Pigment (a.u./µM)")
    ax.set_title("Wound module: higher ssrA -> faster de-repression -> faster pigment")
    ax.grid(True, alpha=0.25)
    no_offset(ax)
    ax.legend()
    plt.tight_layout()
    plt.show()