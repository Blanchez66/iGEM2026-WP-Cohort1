import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt


@dataclass
class EnzParams:
    # Enzyme kinetics (PvdQ on AHL)
    Km_uM: float = 5.0        # uM
    kcat_s: float = 1.0       # 1/s  (reduced from 20 to avoid "instant drop" in plots)

    # Natural loss of AHL (hydrolysis/diffusion/etc.)
    delta_AHL: float = 0.001  # 1/min

    # CRAB AHL production (lumped)
    N_CRAB: float = 1e8       # cells/mL
    q_AHL_uM_min_per_1e8: float = 0.05  # uM/min per (1e8 cells/mL) at full QS

    # QS-dependent production factor f(AHL): leak + Hill(AHL)
    f_leak: float = 0.10
    f_max: float = 1.00
    K_QS_uM: float = 1.0
    n_QS: float = 2.0

    # EcN & secretion -> extracellular enzyme input
    N_EcN: float = 1e8        # cells/mL

    # secretion efficiency (strategy-dependent): OmpA/PelB/HlyA
    eta_sec: float = 0.3

    # Lumped extracellular PvdQ "appearance" flux at eta_sec=1
    # Reduced so curves don't all collapse to ~0 within 2 minutes
    q_Pext_uM_min_per_1e8: float = 2e-4  # uM/min per (1e8 cells/mL) when eta_sec=1

    # Extracellular enzyme loss
    gamma_Pext: float = 0.01  # 1/min


def hill(x, K, n):
    x = max(float(x), 0.0)
    return (x**n) / (K**n + x**n + 1e-12)


def rhs_env(t, y, p: EnzParams):
    """
    y[0] = AHL_ext (uM)
    y[1] = PvdQ_ext (uM)
    """
    A, E = y
    kcat_min = p.kcat_s * 60.0

    # CRAB production with QS-dependent factor
    f_QS = p.f_leak + (p.f_max - p.f_leak) * hill(A, p.K_QS_uM, p.n_QS)
    prod = p.q_AHL_uM_min_per_1e8 * (p.N_CRAB / 1e8) * f_QS  # uM/min

    # Michaelis–Menten degradation
    deg = kcat_min * E * A / (p.Km_uM + A + 1e-12)           # uM/min

    # Natural loss
    loss = p.delta_AHL * A                                  # uM/min

    dA = prod - deg - loss

    # Extracellular PvdQ dynamics (simple secretion + decay)
    sec_in = p.q_Pext_uM_min_per_1e8 * (p.N_EcN / 1e8) * p.eta_sec  # uM/min
    dE = sec_in - p.gamma_Pext * E

    return [dA, dE]


def make_t_eval(t_end=1000.0):

    t1 = np.linspace(0, min(60, t_end), 2401)          # 0.025 min spacing early
    if t_end <= 60:
        return t1
    t2 = np.linspace(60, t_end, 800)                   # coarser later
    return np.unique(np.r_[t1, t2])


def simulate(p: EnzParams, A0_uM=2.0, E0_uM=0.0, t_end=1000.0):
    t_eval = make_t_eval(t_end)
    sol = solve_ivp(
        fun=lambda t, y: rhs_env(t, y, p),
        t_span=(0, t_end),
        y0=[A0_uM, E0_uM],
        t_eval=t_eval,
        method="LSODA",
        rtol=1e-7,
        atol=1e-10
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.t, sol.y[0], sol.y[1]


def clearance_time(t, A, A_thr_uM):
    idx = np.where(A <= A_thr_uM)[0]
    return np.nan if len(idx) == 0 else float(t[idx[0]])


def plot_clearance_strategies(base: EnzParams, strategies, A_thr=0.2, A0=2.0, t_end=1000.0):
    """
    Plots two panels:
      - Left: zoomed early time window (0–60 min) where curves differ
      - Right: full horizon (0–t_end)
    """
    fig, ax = plt.subplots(1, 2, figsize=(12.5, 4.6), sharey=True)

    for name, eta in strategies.items():
        p = EnzParams(**{**base.__dict__, "eta_sec": float(eta)})
        t, A, E = simulate(p, A0_uM=A0, E0_uM=0.0, t_end=t_end)
        tc = clearance_time(t, A, A_thr)

        label = f"{name} (eta={eta:g}), t_clear={tc:.1f} min" if np.isfinite(tc) else f"{name} (eta={eta:g}), no clear"
        ax[0].plot(t, A, lw=2, label=label)
        ax[1].plot(t, A, lw=2, label=label)

    for a in ax:
        a.axhline(A_thr, color="k", ls="--", lw=1, label="AHL threshold")
        a.set_xlabel("Time (min)")
        a.grid(True, alpha=0.25)

    ax[0].set_xlim(0, 60)
    ax[0].set_title("AHL clearance (zoom 0–60 min)")
    ax[0].set_ylabel("[AHL_ext] (uM)")

    ax[1].set_xlim(0, t_end)
    ax[1].set_title(f"AHL clearance (0–{int(t_end)} min)")

    # Only one legend (right panel), avoid duplicates for threshold line
    handles, labels = ax[1].get_legend_handles_labels()
    # keep unique labels
    seen, H, L = set(), [], []
    for h, l in zip(handles, labels):
        if l not in seen:
            seen.add(l); H.append(h); L.append(l)
    ax[1].legend(H, L, loc="upper right", frameon=True)

    plt.tight_layout()
    plt.show()


def plot_dynamics_one_case(p: EnzParams, A_thr=0.2, A0=2.0, t_end=600.0):
    t, A, E = simulate(p, A0_uM=A0, E0_uM=0.0, t_end=t_end)

    fig, ax = plt.subplots(2, 1, figsize=(8.0, 6.0), sharex=True)

    ax[0].plot(t, A, lw=2)
    ax[0].axhline(A_thr, color="k", ls="--", lw=1)
    ax[0].set_ylabel("[AHL_ext] (uM)")
    ax[0].set_title("Dynamics of AHL and extracellular PvdQ")
    ax[0].grid(True, alpha=0.25)

    ax[1].plot(t, E, lw=2, color="C1")
    ax[1].set_ylabel("[PvdQ_ext] (uM)")
    ax[1].set_xlabel("Time (min)")
    ax[1].grid(True, alpha=0.25)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    # Threshold below which QS is considered OFF
    A_thr = 0.2  # uM

    # Base parameters 
    base = EnzParams(
        Km_uM=5.0,
        kcat_s=1.0,
        N_CRAB=1e8,
        N_EcN=1e8,
        q_AHL_uM_min_per_1e8=0.05,
        q_Pext_uM_min_per_1e8=2e-4,
        gamma_Pext=0.01
    )

    # Strategy comparison by secretion efficiency
    strategies = {
        "OmpA": 0.2,
        "PelB": 0.3,
        "HlyA": 0.6
    }

    plot_clearance_strategies(
        base=base,
        strategies=strategies,
        A_thr=A_thr,
        A0=2.0,
        t_end=1000.0
    )

    # One-case dynamics (AHL + PvdQ_ext)
    p_example = EnzParams(**{**base.__dict__, "eta_sec": 0.3})
    plot_dynamics_one_case(p_example, A_thr=A_thr, A0=2.0, t_end=600.0)