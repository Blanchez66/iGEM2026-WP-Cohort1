import numpy as np
from dataclasses import dataclass
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

@dataclass
class Params:
    # QS regulation f_QS(c)
    K_QS: float = 1.0
    n_QS: float = 2.0

    # Planktonic P dynamics
    mu_P: float = 0.02
    Pmax: float = 1.0
    delta_P: float = 0.002

    # Biofilm B dynamics
    mu_B: float = 0.012
    Bmax: float = 1.0
    delta_B: float = 0.0015

    # Attachment/detachment
    k_attach: float = 0.03
    k_detach: float = 0.01

    # EPS E dynamics
    r_E: float = 0.04
    delta_E: float = 0.01

    # AHL (c) dynamics: production - degradation - natural loss
    # Production depends on total CRAB and QS (simple positive feedback lump)
    r_c: float = 0.08          # uM/min per density unit
    c_leak: float = 0.005      # uM/min baseline
    delta_c: float = 0.01      # 1/min natural loss

    # PvdQ quenching (lumped Michaelis–Menten): deg = kq*PvdQ*c/(Km + c)
    kq: float = 0.3            # 1/min per (PvdQ unit)
    Km_q: float = 5.0          # uM

    # Antibiotic killing (optional): kill rate = kmax * Ab^h / (MIC^h + Ab^h)
    Ab: float = 0.0            # antibiotic concentration (a.u.)
    h_ab: float = 2.0
    kmax_P: float = 0.04       # 1/min
    kmax_B: float = 0.02       # 1/min

    # MIC-EPS relationship
    MIC_planktonic: float = 1.0
    phi: float = 30.0          # max fold-increase from EPS (10–1000 typical)
    K_E: float = 0.3

def f_QS(c, p: Params):
    c = max(float(c), 0.0)
    return (c**p.n_QS) / (p.K_QS**p.n_QS + c**p.n_QS + 1e-12)

def MIC_effective(E, p: Params):
    return p.MIC_planktonic * (1.0 + p.phi * (E / (E + p.K_E + 1e-12)))

def kill_rate(Ab, MIC, kmax, h):
    # smooth saturating kill; when Ab << MIC, kill small; when Ab >> MIC, near kmax
    return kmax * (Ab**h) / (MIC**h + Ab**h + 1e-12)

def rhs(t, y, p: Params, PvdQ_level: float):
    # y = [P, B, E, c]
    P, B, E, c = y
    P = max(P, 0.0); B = max(B, 0.0); E = max(E, 0.0); c = max(c, 0.0)

    fq = f_QS(c, p)

    # Antibiotic effects (MIC for B depends on EPS; P uses planktonic MIC)
    MIC_B = MIC_effective(E, p)
    kP = kill_rate(p.Ab, p.MIC_planktonic, p.kmax_P, p.h_ab)
    kB = kill_rate(p.Ab, MIC_B,            p.kmax_B, p.h_ab)

    # P, B, E
    dP = p.mu_P * P * (1 - P / p.Pmax) \
         - p.k_attach * fq * P \
         + p.k_detach * B \
         - p.delta_P * P \
         - kP * P

    dB = p.k_attach * fq * P \
         + p.mu_B * B * (1 - B / p.Bmax) \
         - p.k_detach * B \
         - p.delta_B * B \
         - kB * B

    dE = p.r_E * fq * B - p.delta_E * E

    # AHL c: production from CRAB + leak - quenching - natural loss
    prod_c = p.c_leak + p.r_c * (P + B) * fq
    deg_c = p.kq * PvdQ_level * c / (p.Km_q + c + 1e-12)
    dc  = prod_c - deg_c - p.delta_c * c

    return [dP, dB, dE, dc]

def simulate(p: Params, PvdQ_level=0.0, t_end=1000):
    y0 = [0.6, 0.05, 0.05, 2.0]  # initial P, B, E, c (editable)
    t_eval = np.unique(np.r_[np.linspace(0, 200, 801), np.linspace(200, t_end, 801)])

    sol = solve_ivp(
        fun=lambda t, y: rhs(t, y, p, PvdQ_level),
        t_span=(0, t_end),
        y0=y0,
        t_eval=t_eval,
        method="LSODA",
        rtol=1e-7,
        atol=1e-10
    )
    if not sol.success:
        raise RuntimeError(sol.message)

    P, B, E, c = sol.y
    MICB = np.array([MIC_effective(e, p) for e in E])
    return sol.t, P, B, E, c, MICB

def find_min_PvdQ_for_MIC(p: Params, target_MIC: float, t_check=(200, 800),
                          grid=np.logspace(-3, 1, 60)):
    """
    Find smallest PvdQ_level such that MIC_effective(t) <= target_MIC
    for at least some sustained portion in [t_check[0], t_check[1]].
    """
    t0, t1 = t_check
    for q in grid:
        t, P, B, E, c, MICB = simulate(p, PvdQ_level=q, t_end=max(1000, int(t1)))
        mask = (t >= t0) & (t <= t1)
        # condition: MICB below target for >=20% of points in the window
        ok = np.mean(MICB[mask] <= target_MIC) >= 0.2
        if ok:
            return q
    return np.nan


if __name__ == "__main__":
  
    p = Params()

    # Example: add antibiotic to demonstrate "quenching + antibiotic" synergy
    p.Ab = 1.0  # (a.u.) set 0 for no antibiotic

    # Case 1: no quorum quenching
    t0, P0, B0, E0, c0, MIC0 = simulate(p, PvdQ_level=0.0, t_end=1000)

    # Case 2: with quorum quenching (set a moderate level)
    t1, P1, B1, E1, c1, MIC1 = simulate(p, PvdQ_level=0.3, t_end=1000)

    # Plots: B(t), E(t), c(t), MIC_eff(t) 
    fig, ax = plt.subplots(2, 2, figsize=(11, 7))
    ax = ax.ravel()

    ax[0].plot(t0, B0, label="No QQ (PvdQ=0)")
    ax[0].plot(t1, B1, label="With QQ (PvdQ=0.3)")
    ax[0].set_title("Biofilm population B(t)")
    ax[0].set_xlabel("t (min)"); ax[0].set_ylabel("B")
    ax[0].grid(True, alpha=0.25); ax[0].legend()

    ax[1].plot(t0, E0, label="No QQ")
    ax[1].plot(t1, E1, label="With QQ")
    ax[1].set_title("EPS matrix E(t)")
    ax[1].set_xlabel("t (min)"); ax[1].set_ylabel("E")
    ax[1].grid(True, alpha=0.25); ax[1].legend()

    ax[2].plot(t0, c0, label="No QQ")
    ax[2].plot(t1, c1, label="With QQ")
    ax[2].set_title("AHL signal c(t)")
    ax[2].set_xlabel("t (min)"); ax[2].set_ylabel("c (uM)")
    ax[2].grid(True, alpha=0.25); ax[2].legend()

    ax[3].plot(t0, MIC0, label="No QQ")
    ax[3].plot(t1, MIC1, label="With QQ")
    ax[3].axhline(p.Ab, color="k", ls="--", lw=1, label="Antibiotic level (Ab)")
    ax[3].set_title("MIC_effective(t) from EPS")
    ax[3].set_xlabel("t (min)"); ax[3].set_ylabel("MIC_effective")
    ax[3].grid(True, alpha=0.25); ax[3].legend()

    plt.tight_layout()
    plt.show()

    # "Therapeutic window": minimal PvdQ to bring MIC below Ab sometimes 
    target_MIC = p.Ab  # require MIC_effective <= Ab
    q_star = find_min_PvdQ_for_MIC(p, target_MIC=target_MIC, t_check=(200, 800))
    print(f"Approx. minimal PvdQ level to reach MIC_effective <= Ab in 200–800 min: {q_star}")